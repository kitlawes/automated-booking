jQuery(document).ready(function($) {
	$(".datepicker").datepicker();
});