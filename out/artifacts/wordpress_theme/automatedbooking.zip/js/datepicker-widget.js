jQuery(document).ready(function($) {
	$(".datepicker").datepicker({dateFormat: 'dd/mm/yy'});
});